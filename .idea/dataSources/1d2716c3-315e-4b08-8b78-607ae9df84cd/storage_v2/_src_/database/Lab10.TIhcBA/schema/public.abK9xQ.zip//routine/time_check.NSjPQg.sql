create function time_check() returns trigger
    language plpgsql
as
$$
BEGIN

IF (SELECT NOT EXISTS (SELECT * FROM sessions
    WHERE NEW.session_code <> session_code
      AND NEW.hall_code = hall_code
      AND NEW.start_time + NEW.duration > start_time
      AND NEW.start_time < start_time + duration)) THEN
    RETURN NEW;
ELSE
    RAISE EXCEPTION 'Сеанс пересекается с другим!';
END IF;

END;
$$;

alter function time_check() owner to postgres;

