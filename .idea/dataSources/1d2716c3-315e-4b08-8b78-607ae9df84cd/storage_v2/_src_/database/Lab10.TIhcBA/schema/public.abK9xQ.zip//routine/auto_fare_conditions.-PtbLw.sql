create function auto_fare_conditions() returns trigger
    language plpgsql
as
$$
BEGIN

IF (NEW.fare_conditions is NULL) THEN
    IF (NEW.row <= 3) THEN
       NEW.fare_conditions = 'Economy'::text;
    ELSIF  (NEW.row > 7) THEN
       NEW.fare_conditions = 'Comfort'::text;
    ELSE
       NEW.fare_conditions = 'Business'::text;
  END IF;
END IF;
RETURN NEW;
END;
$$;

alter function auto_fare_conditions() owner to postgres;

