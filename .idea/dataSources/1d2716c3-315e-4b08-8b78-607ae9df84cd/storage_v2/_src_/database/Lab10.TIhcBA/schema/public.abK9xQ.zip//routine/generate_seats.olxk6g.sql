create function generate_seats(hall_code_in numeric, row_num numeric, seat_num numeric)
    returns TABLE(hall_code numeric, row_n numeric, seat_n numeric, x text)
    language plpgsql
as
$$
BEGIN
IF(NOT EXISTS(SELECT * FROM halls h WHERE h.hall_code = hall_code_in)) THEN
 RAISE EXCEPTION 'Зал не найден!';
ELSE
 RETURN QUERY
 INSERT INTO seats SELECT hall_code_in, row_nn, seat_nn
 FROM generate_series(1, row_num) AS row_ns (row_nn)
     NATURAL JOIN
 generate_series(1, seat_num) AS seat_ns (seat_nn)
 ON CONFLICT DO NOTHING RETURNING *;
end if;
END
$$;

alter function generate_seats(numeric, numeric, numeric) owner to postgres;

