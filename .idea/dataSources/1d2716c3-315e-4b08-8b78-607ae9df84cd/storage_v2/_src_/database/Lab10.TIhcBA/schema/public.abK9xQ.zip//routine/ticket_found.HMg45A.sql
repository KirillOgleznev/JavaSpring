create function ticket_found(ticket_c integer)
    returns TABLE(a text, b text, c text, d text, e text)
    language sql
as
$$
SELECT film_name::text, to_char( start_time, 'HH24:MI DD-MM-YYYY' ),
       name::text, row::text  || ' ряд', seat_num::text || ' место'
FROM tickets t , sessions s, halls h
WHERE ticket_code = ticket_c
  AND t.hall_code = h.hall_code
  AND s.session_code = t.session_code;

$$;

alter function ticket_found(integer) owner to postgres;

