create function show_sessions(hall_c integer, session_c integer)
    returns TABLE(a text, b text)
    language sql
as
$$
SELECT row::text, seat_num::text::text
FROM tickets WHERE hall_code = hall_c AND session_code = session_c
GROUP BY row, seat_num;

$$;

alter function show_sessions(integer, integer) owner to postgres;

