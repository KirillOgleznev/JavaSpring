create function ticket_add(b integer, c integer, d integer, e integer, f text)
    returns TABLE(aa integer, ba numeric, ca integer, da numeric, ea numeric, fa numeric)
    language sql
as
$$
INSERT INTO tickets VALUES (DEFAULT, b::numeric(3),c::int, d::numeric(2), e::numeric(2), f::numeric(10,2))
RETURNING *;

$$;

alter function ticket_add(integer, integer, integer, integer, text) owner to postgres;

